# AUTHOR: Tosin D. Oyetoyan
# 
rm(list=ls()) #remove all objects

library(effsize)

setwd("data/analysis/odcv")
# source("scripts/stat.R")
source("data/analysis/scripts/metrics.R")
# fsec-ext
file.extp.tpp <- "fsecext_true_all_tpp.csv"
file.extm.tpp <- "fsecext_false_all_tpp.csv"
file.extp.wpp <- "fsecext_true_all_wpp.csv"
file.extm.wpp <- "fsecext_false_all_wpp.csv"

# fsec-tfidf
file.tfidfp.tpp <- "fsectfidf_true_all_tpp.csv"
file.tfidfm.tpp <- "fsectfidf_false_all_tpp.csv"
file.tfidfp.wpp <- "fsectfidf_true_all_wpp.csv"
file.tfidfm.wpp <- "fsectfidf_false_all_wpp.csv"

# paired
file.extpr.tpp <- "fsecext_true_all_paired_tpp.csv"
file.extmr.tpp <- "fsecext_false_all_paired_tpp.csv"
file.extpr.wpp <- "fsecext_true_all_paired_wpp.csv"
file.extmr.wpp <- "fsecext_false_all_paired_wpp.csv"

# fsec-tfidf
file.tfidfpr.tpp <- "fsectfidf_true_all_paired_tpp.csv"
file.tfidfmr.tpp <- "fsectfidf_false_all_paired_tpp.csv"
file.tfidfpr.wpp <- "fsectfidf_true_all_paired_wpp.csv"
file.tfidfmr.wpp <- "fsectfidf_false_all_paired_wpp.csv"

file.out <- "wilcoxonstat.csv"
#file.hedges <- "results/hedgesstat.csv"

#tpp
data.extp.tpp <- read.csv(file.extp.tpp, header=TRUE, sep=";")
data.extm.tpp <- read.csv(file.extm.tpp, header=TRUE, sep=";")
data.tfidfp.tpp <- read.csv(file.tfidfp.tpp, header=TRUE, sep=";")
data.tfidfm.tpp <- read.csv(file.tfidfm.tpp, header=TRUE, sep=";")

# wpp
data.extp.wpp <- read.csv(file.extp.wpp, header=TRUE, sep=";")
data.extm.wpp <- read.csv(file.extm.wpp, header=TRUE, sep=";")
data.tfidfp.wpp <- read.csv(file.tfidfp.wpp, header=TRUE, sep=";")
data.tfidfm.wpp <- read.csv(file.tfidfm.wpp, header=TRUE, sep=";")

# paired
#tpp
data.extpr.tpp <- read.csv(file.extpr.tpp, header=TRUE, sep=";")
data.extmr.tpp <- read.csv(file.extmr.tpp, header=TRUE, sep=";")
data.tfidfpr.tpp <- read.csv(file.tfidfpr.tpp, header=TRUE, sep=";")
data.tfidfmr.tpp <- read.csv(file.tfidfmr.tpp, header=TRUE, sep=";")

# wpp
data.extpr.wpp <- read.csv(file.extpr.wpp, header=TRUE, sep=";")
data.extmr.wpp <- read.csv(file.extmr.wpp, header=TRUE, sep=";")
data.tfidfpr.wpp <- read.csv(file.tfidfpr.wpp, header=TRUE, sep=";")
data.tfidfmr.wpp <- read.csv(file.tfidfmr.wpp, header=TRUE, sep=";")

label <- ""
r1 <- 0
r2 <- 0
# labels - mean-recall, mean-fscore, mean-gmeasure
# TPP: source 	 target 	 feature.sel.approach	 class.bal.ratio	 sec.feature.include	 security.category	 algorithm	 TN	TP	FN	FP	 Pd	Pf	Prec	F-measure	G-measure	AuROC	Kappa  
# WPP: source 	 target 	 feature.sel.approach	 class.bal.ratio	 sec.feature.include	 security.category	 algorithm	 TN	TP	FN	FP	 Pd	Pf	Prec	F-measure	G-measure	AuROC	Kappa  


write.table("Statistical test results", file.out, sep=";", append=FALSE)

#### Hypothesis 1
## Top 20 observations unpaired data points
# TPP
# fscore, g-measure, recall 
r1 <- 1
r2 <- 20
fname <- " TPP: fsec-ext+ vs fsec-tfidf+"
recall(data.extp.tpp, data.tfidfp.tpp, fname, FALSE)
fscore(data.extp.tpp, data.tfidfp.tpp, fname, FALSE)
gscore(data.extp.tpp, data.tfidfp.tpp, fname, FALSE)


fname <- "TPP: fsec-ext vs fsec-tfidf"
recall(data.extm.tpp, data.tfidfm.tpp, fname, FALSE)
fscore(data.extm.tpp, data.tfidfm.tpp, fname, FALSE)
gscore(data.extm.tpp, data.tfidfm.tpp, fname, FALSE)

#### Hypothesis 2
## Paired data points - group1 (no sec incl) vs group2 (sec incl)
# TPP
# fscore, g-measure, recall 
r1 <- 1
r2 <- 1400
fname <- " TPP: fsec-ext+ vs fsec-ext"
recall(data.extpr.tpp, data.extmr.tpp, fname, TRUE)
fscore(data.extpr.tpp, data.extmr.tpp, fname, TRUE)
gscore(data.extpr.tpp, data.extmr.tpp, fname, TRUE)


r1 <- 1
r2 <- 200
fname <- "TPP: fsec-tfidf+ vs fsec-tfidf"
recall(data.tfidfpr.tpp, data.tfidfmr.tpp, fname, TRUE)
fscore(data.tfidfpr.tpp, data.tfidfmr.tpp, fname, TRUE)
gscore(data.tfidfpr.tpp, data.tfidfmr.tpp, fname, TRUE)


# WPP
r1 <- 1
r2 <- 175
fname <- " WPP: fsec-ext+ vs fsec-ext"
recall(data.extpr.wpp, data.extmr.wpp, fname, TRUE)
fscore(data.extpr.wpp, data.extmr.wpp, fname, TRUE)
gscore(data.extpr.wpp, data.extmr.wpp, fname, TRUE)


r1 <- 1
r2 <- 25
fname <- "WPP: fsec-tfidf+ vs fsec-tfidf"
recall(data.tfidfp.wpp, data.tfidfm.wpp, fname, TRUE)
fscore(data.tfidfp.wpp, data.tfidfm.wpp, fname, TRUE)
gscore(data.tfidfp.wpp, data.tfidfm.wpp, fname, TRUE)



#### Hypothesis 3
# WPP (Top 20 observations unpaired data points)
# fscore, g-measure, recall 
r1 <- 1
r2 <- 20
fname <- " WPP: fsec-ext+ vs fsec-tfidf+"
recall(data.extp.wpp, data.tfidfp.wpp, fname, FALSE)
fscore(data.extp.wpp, data.tfidfp.wpp, fname, FALSE)
gscore(data.extp.wpp, data.tfidfp.wpp, fname, FALSE)


fname <- "WPP: fsec-ext vs fsec-tfidf"
recall(data.extm.wpp, data.tfidfm.wpp, fname, FALSE)
fscore(data.extm.wpp, data.tfidfm.wpp, fname, FALSE)
gscore(data.extm.wpp, data.tfidfm.wpp, fname, FALSE)