# AUTHOR: Tosin D. Oyetoyan
# 

# labels - mean-recall, mean-fscore, mean-gmeasure
# TPP: source 	 target 	 feature.sel.approach	 class.bal.ratio	 sec.feature.include	 security.category	 algorithm	 TN	TP	FN	FP	 Pd	Pf	Prec	F-measure	G-measure	AuROC	Kappa  
# WPP: source 	 target 	 feature.sel.approach	 class.bal.ratio	 sec.feature.include	 security.category	 algorithm	 TN	TP	FN	FP	 Pd	Pf	Prec	F-measure	G-measure	AuROC	Kappa  

fscore <- function(pdata, mdata, ftitle, pair){
	fsec.p <- pdata$Fmeasure[r1:r2]
	fsec.m <- mdata$Fmeasure[r1:r2]
	wilcox.fext.p <- wilcox.test(fsec.p, fsec.m, paired = pair, alternative = "greater", exact=FALSE, conf.level=0.95)
	wtest.name <- paste(ftitle," Wilcoxon: fscore ", sep="")
	# write.table(wtest.name, file.out, append=TRUE, sep=";")
	wilcox.fext.p <- paste(wtest.name, wilcox.fext.p$p.value, sep=";")
	write.table(wilcox.fext.p, file.out, append=TRUE, sep=";", col.names=FALSE)

	# effect size
	cohens <- cohen.d(fsec.p, fsec.m, paired = pair, na.rm=TRUE, hedges.correction=TRUE, conf.level=0.95)
	ctest.name <- paste(ftitle," Effect Size: fscore ", sep="")
	# write.table(ctest.name, file.out, append=TRUE, sep=";")
	cohens <- paste(ctest.name, cohens$method, cohens$estimate, cohens$magnitude, sep=";")
	write.table(cohens, file.out, append=TRUE, sep=";", col.names=FALSE)
}

gscore <- function(pdata, mdata, ftitle, pair){
	gsec.p <- pdata$Gmeasure[r1:r2]
	gsec.m <- mdata$Gmeasure[r1:r2]
	wilcox.fext.p <- wilcox.test(gsec.p, gsec.m, paired = pair, alternative = "greater", exact=FALSE, conf.level=0.95)
	wtest.name <- paste(ftitle," Wilcoxon: g-measure ", sep=";")
	# write.table(wtest.name, file.out, append=TRUE, sep=";")
	wilcox.fext.p <- paste(wtest.name, wilcox.fext.p$p.value, sep=";")
	write.table(wilcox.fext.p, file.out, append=TRUE, sep=";", col.names=FALSE)

	# effect size
	cohens <- cohen.d(gsec.p, gsec.m, paired = pair, na.rm=TRUE, hedges.correction=TRUE, conf.level=0.95)
	ctest.name <- paste(ftitle," Effect Size: g-measure ", sep=";")
	# write.table(ctest.name, file.out, append=TRUE, sep=";")
	cohens <- paste(ctest.name, cohens$method, cohens$estimate, cohens$magnitude, sep=";")
	write.table(cohens, file.out, append=TRUE, sep=";", col.names=FALSE)
}

recall <- function(pdata, mdata, ftitle, pair){
	rsec.p <- pdata$Pd[r1:r2]
	rsec.m <- mdata$Pd[r1:r2]
	wilcox.fext.p <- wilcox.test(rsec.p, rsec.m, paired = pair, alternative = "greater", exact=FALSE, conf.level=0.95)
	wtest.name <- paste(ftitle, "Wilcoxon: recall ", sep="")
	# write.table(wtest.name, file.out, append=TRUE, sep=";")
	wilcox.fext.p <- paste(wtest.name, wilcox.fext.p$p.value, sep=";")
	write.table(wilcox.fext.p, file.out, append=TRUE, sep=";", col.names=FALSE)

	# effect size
	cohens <- cohen.d(rsec.p, rsec.m, paired = pair, na.rm=TRUE, hedges.correction=TRUE, conf.level=0.95)
	ctest.name <- paste(ftitle," Effect Size: recall ", sep="")
	# write.table(ctest.name, file.out, append=TRUE, sep=";")
	cohens <- paste(ctest.name, cohens$method, cohens$estimate, cohens$magnitude, sep=";")
	write.table(cohens, file.out, append=TRUE, sep=";", col.names=FALSE)
}
