# AUTHOR: Tosin D. Oyetoyan
# 
rm(list=ls()) #remove all objects

library(effsize)

setwd("/Users/tdoy/TSE-Paper/experiments/adata/analysis/")
# source("scripts/stat.R")

# fsec-ext
file.extp.tpp <- "fsec_extp_tpp.csv"
file.extm.tpp <- "fsec_extm_tpp.csv"
file.extp.wpp <- "fsec_extp_wpp.csv"
file.extm.wpp <- "fsec_extm_wpp.csv"

# fsec-tfidf
file.tfidfp.tpp <- "fsec_tfidfp_tpp.csv"
file.tfidfm.tpp <- "fsec_tfidfm_tpp.csv"
file.tfidfp.wpp <- "fsec_tfidfp_wpp.csv"
file.tfidfm.wpp <- "fsec_tfidfm_wpp.csv"


file.out <- "wilcoxonstat.csv"
#file.hedges <- "results/hedgesstat.csv"

#tpp
data.extp.tpp <- read.csv(file.extp.tpp, header=TRUE, sep=";")
data.extm.tpp <- read.csv(file.extm.tpp, header=TRUE, sep=";")
data.tfidfp.tpp <- read.csv(file.tfidfp.tpp, header=TRUE, sep=";")
data.tfidfm.tpp <- read.csv(file.tfidfm.tpp, header=TRUE, sep=";")

# wpp
data.extp.wpp <- read.csv(file.extp.wpp, header=TRUE, sep=";")
data.extm.wpp <- read.csv(file.extm.wpp, header=TRUE, sep=";")
data.tfidfp.wpp <- read.csv(file.tfidfp.wpp, header=TRUE, sep=";")
data.tfidfm.wpp <- read.csv(file.tfidfm.wpp, header=TRUE, sep=";")


label <- ""
# r1 <- 1
# r2 <- 154
# labels - mean-recall, mean-fscore, mean-gmeasure
# TPP: source 	 target 	 feature.sel.approach	 class.bal.ratio	 sec.feature.include	 security.category	 algorithm	 TN	TP	FN	FP	 Pd	Pf	Prec	F-measure	G-measure	AuROC	Kappa  
# WPP: source 	 target 	 feature.sel.approach	 class.bal.ratio	 sec.feature.include	 security.category	 algorithm	 TN	TP	FN	FP	 Pd	Pf	Prec	F-measure	G-measure	AuROC	Kappa  

fscore <- function(pdata, mdata, ftitle){
	wilcox.fext.p <- wilcox.test(pdata$Fmeasure, mdata$Fmeasure, paired = FALSE, alternative = "greater", exact=FALSE, conf.level=0.95)
	wtest.name <- paste("Wilcoxon: fscore ",ftitle, sep="")
	write.table(wtest.name, file.out, append=TRUE, sep=";")
	wilcox.fext.p <- paste(wilcox.fext.p$p.value, wilcox.fext.p$statistic, sep=" V")
	write.table(wilcox.fext.p, file.out, append=TRUE, sep=";", col.names=TRUE)

	# effect size
	cohens <- cohen.d(pdata$Fmeasure, mdata$Fmeasure, paired=FALSE, na.rm=TRUE, hedges.correction=TRUE, conf.level=0.95)
	ctest.name <- paste("Effect Size: fscore ",ftitle, sep="")
	write.table(ctest.name, file.out, append=TRUE, sep=";")
	cohens <- paste(cohens$method, cohens$estimate, cohens$magnitude, sep=";")
	write.table(cohens, file.out, append=TRUE, col.names=TRUE)
}

gscore <- function(pdata, mdata, ftitle){
	wilcox.fext.p <- wilcox.test(pdata$Gmeasure, mdata$Gmeasure, paired = FALSE, alternative = "greater", exact=FALSE, conf.level=0.95)
	wtest.name <- paste("Wilcoxon: g-measure ",ftitle, sep="")
	write.table(wtest.name, file.out, append=TRUE, sep=";")
	wilcox.fext.p <- paste(wilcox.fext.p$p.value, wilcox.fext.p$statistic, sep=" V")
	write.table(wilcox.fext.p, file.out, append=TRUE, sep=";", col.names=TRUE)

	# effect size
	cohens <- cohen.d(pdata$Gmeasure, mdata$Gmeasure, paired=FALSE, na.rm=TRUE, hedges.correction=TRUE, conf.level=0.95)
	ctest.name <- paste("Effect Size: g-measure ",ftitle, sep="")
	write.table(ctest.name, file.out, append=TRUE, sep=";")
	cohens <- paste(cohens$method, cohens$estimate, cohens$magnitude, sep=";")
	write.table(cohens, file.out, append=TRUE, col.names=TRUE)
}

recall <- function(pdata, mdata, ftitle){
	wilcox.fext.p <- wilcox.test(pdata$Pd, mdata$Pd, paired = FALSE, alternative = "greater", exact=FALSE, conf.level=0.95)
	wtest.name <- paste("Wilcoxon: recall ",ftitle, sep="")
	write.table(wtest.name, file.out, append=TRUE, sep=";")
	wilcox.fext.p <- paste(wilcox.fext.p$p.value, wilcox.fext.p$statistic, sep=" V")
	write.table(wilcox.fext.p, file.out, append=TRUE, sep=";", col.names=TRUE)

	# effect size
	cohens <- cohen.d(pdata$Pd, mdata$Pd, paired=FALSE, na.rm=TRUE, hedges.correction=TRUE, conf.level=0.95)
	ctest.name <- paste("Effect Size: recall ",ftitle, sep="")
	write.table(ctest.name, file.out, append=TRUE, sep=";")
	cohens <- paste(cohens$method, cohens$estimate, cohens$magnitude, sep=";")
	write.table(cohens, file.out, append=TRUE, col.names=TRUE)
}

write.table("Statistical test results", file.out, append=FALSE)
#### Hypothesis 1
# TPP
# fscore, g-measure, recall 
fname <- " TPP: fsec-ext+ vs fsec-ext-"
fscore(data.extp.tpp, data.extm.tpp, fname)
gscore(data.extp.tpp, data.extm.tpp, fname)
recall(data.extp.tpp, data.extm.tpp, fname)

fname <- "TPP: fsec-tfidf+ vs fsec-tfidf-"
fscore(data.tfidfp.tpp, data.tfidfm.tpp, fname)
gscore(data.tfidfp.tpp, data.tfidfm.tpp, fname)
recall(data.tfidfp.tpp, data.tfidfm.tpp, fname)


# WPP
fname <- " WPP: fsec-ext+ vs fsec-ext-"
fscore(data.extp.wpp, data.extm.wpp, fname)
gscore(data.extp.wpp, data.extm.wpp, fname)
recall(data.extp.wpp, data.extm.wpp, fname)

fname <- "WPP: fsec-tfidf+ vs fsec-tfidf-"
fscore(data.tfidfp.wpp, data.tfidfm.wpp, fname)
gscore(data.tfidfp.wpp, data.tfidfm.wpp, fname)
recall(data.tfidfp.wpp, data.tfidfm.wpp, fname)


#### Hypothesis 2
# TPP
# fscore, g-measure, recall 
fname <- " TPP: fsec-ext+ vs fsec-tfidf+"
fscore(data.extp.tpp, data.tfidfp.tpp, fname)
gscore(data.extp.tpp, data.tfidfp.tpp, fname)
recall(data.extp.tpp, data.tfidfp.tpp, fname)

fname <- "TPP: fsec-ext+ vs fsec-tfidf+"
fscore(data.extp.tpp, data.tfidfp.tpp, fname)
gscore(data.extp.tpp, data.tfidfp.tpp, fname)
recall(data.extp.tpp, data.tfidfp.tpp, fname)


