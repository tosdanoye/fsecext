# AUTHOR: Tosin D. Oyetoyan
# 
rm(list=ls()) #remove all objects

library(effsize)

setwd("/Users/tdoy/TSE-Paper/experiments/adata/analysis")
# source("scripts/runSumm.R")

setwd("/Users/tdoy/TSE-Paper/experiments/adata/analysis/chromium")
source("scripts/stat.R")

setwd("/Users/tdoy/TSE-Paper/experiments/adata/analysis/wicket")
source("scripts/stat.R")

setwd("/Users/tdoy/TSE-Paper/experiments/adata/analysis/ambari")
source("scripts/stat.R")

setwd("/Users/tdoy/TSE-Paper/experiments/adata/analysis/camel")
source("scripts/stat.R")

setwd("/Users/tdoy/TSE-Paper/experiments/adata/analysis/derby")
source("scripts/stat.R")

setwd("/Users/tdoy/TSE-Paper/experiments/adata/analysis/odcv")
source("scripts/stat.R")

setwd("/Users/tdoy/TSE-Paper/experiments/adata/analysis/apache")
source("scripts/stat.R")

setwd("/Users/tdoy/TSE-Paper/experiments/adata/analysis/mozilla")
source("scripts/stat.R")

setwd("/Users/tdoy/TSE-Paper/experiments/adata/analysis/comm")
source("scripts/stat.R")